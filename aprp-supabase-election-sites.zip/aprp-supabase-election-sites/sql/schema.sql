-- APRP Live Election Supabase schema
-- Run this in Supabase SQL Editor once.

create extension if not exists pgcrypto;

create table if not exists public.elections (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null default 'current',
  title text not null default 'APRP Presidential Election',
  subtitle text default 'Live Results',
  year text default '',
  win_threshold integer not null default 270,
  total_electoral_votes integer not null default 538,
  active boolean not null default true,
  candidates jsonb not null default '[
    {"id":"gop","party":"GOP","name":"Republican Candidate","shortName":"GOP","color":"#e74c3c","image":""},
    {"id":"dem","party":"DNC","name":"Democratic Candidate","shortName":"DNC","color":"#3498db","image":""},
    {"id":"ind","party":"IND","name":"Independent","shortName":"IND","color":"#9b59b6","image":""}
  ]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.state_results (
  id uuid primary key default gen_random_uuid(),
  election_id uuid not null references public.elections(id) on delete cascade,
  abbr text not null,
  state_name text not null,
  electoral_votes integer not null default 0,
  total_turnout integer not null default 0, -- expected full turnout / total available votes for this race in the state
  turnout_pct numeric(5,2) not null default 0 check (turnout_pct >= 0 and turnout_pct <= 100), -- percent of total_turnout currently counted/reporting
  gop_pct numeric(5,2) not null default 0 check (gop_pct >= 0 and gop_pct <= 100),
  dem_pct numeric(5,2) not null default 0 check (dem_pct >= 0 and dem_pct <= 100),
  ind_pct numeric(5,2) not null default 0 check (ind_pct >= 0 and ind_pct <= 100),
  called_party text default '', -- blank, gop, dem, ind. Leave blank to auto-call only at 100% turnout.
  locked boolean not null default false,
  updated_at timestamptz not null default now(),
  unique(election_id, abbr)
);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists elections_touch_updated_at on public.elections;
create trigger elections_touch_updated_at before update on public.elections
for each row execute function public.touch_updated_at();

drop trigger if exists state_results_touch_updated_at on public.state_results;
create trigger state_results_touch_updated_at before update on public.state_results
for each row execute function public.touch_updated_at();

alter table public.elections enable row level security;
alter table public.state_results enable row level security;

-- Public site can read active election data.
drop policy if exists "Public read elections" on public.elections;
create policy "Public read elections" on public.elections
for select using (active = true);

drop policy if exists "Public read state results" on public.state_results;
create policy "Public read state results" on public.state_results
for select using (
  exists (select 1 from public.elections e where e.id = state_results.election_id and e.active = true)
);

-- Authenticated Supabase users can manage election data.
-- Add your admins in Supabase Authentication. Do not share admin accounts.
drop policy if exists "Authenticated manage elections" on public.elections;
create policy "Authenticated manage elections" on public.elections
for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Authenticated manage state results" on public.state_results;
create policy "Authenticated manage state results" on public.state_results
for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

insert into public.elections (slug, title, subtitle, year, active)
values ('current', 'APRP Presidential Election', 'Live Results', '2010', true)
on conflict (slug) do nothing;
