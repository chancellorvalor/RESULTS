(() => {
  const cfg = window.APRP_CONFIG;
  const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
  const els = {
    status: document.getElementById('status'), session: document.getElementById('session-status'), logout: document.getElementById('logout'),
    loginCard: document.getElementById('login-card'), adminApp: document.getElementById('admin-app'), loginError: document.getElementById('login-error'),
    email: document.getElementById('email'), password: document.getElementById('password'), rows: document.getElementById('rows'), search: document.getElementById('search'),
    title: document.getElementById('title'), subtitle: document.getElementById('subtitle'), year: document.getElementById('year'), win: document.getElementById('win-threshold'), totalEv: document.getElementById('total-ev'), candidates: document.getElementById('candidate-editor')
  };
  let election, stateRows = [], candidates = [], stateBase = [];

  document.addEventListener('DOMContentLoaded', init);
  async function init(){
    document.getElementById('login').onclick = login;
    els.logout.onclick = logout;
    document.getElementById('save-election').onclick = saveElection;
    document.getElementById('seed-states').onclick = seedStates;
    document.getElementById('save-all').onclick = saveAllRows;
    document.getElementById('normalize-visible').onclick = normalizeVisible;
    els.search.oninput = renderRows;
    await loadBaseStates();
    const { data:{ session } } = await sb.auth.getSession();
    setSession(session);
    if (session) await loadAdmin();
    sb.auth.onAuthStateChange(async (_event, session) => { setSession(session); if (session) await loadAdmin(); });
  }
  async function loadBaseStates(){
    const res = await fetch('../public/data/states.geojson');
    const gj = await res.json();
    const seen = new Map();
    gj.features.forEach(f=>{
      const p=f.properties||{}; const abbr=p.abbr||p.STUSPS||p.postal;
      if (!abbr || abbr==='PR' || seen.has(abbr)) return;
      seen.set(abbr,{abbr,state_name:p.NAME||p.name||abbr,electoral_votes:Number(p.electoral_votes||0)});
    });
    stateBase = [...seen.values()].sort((a,b)=>a.state_name.localeCompare(b.state_name));
  }
  function setSession(session){
    const signed = !!session;
    els.loginCard.classList.toggle('hidden', signed);
    els.adminApp.classList.toggle('hidden', !signed);
    els.logout.classList.toggle('hidden', !signed);
    els.session.textContent = signed ? `Signed in: ${session.user.email}` : 'Signed out';
  }
  async function login(){
    els.loginError.classList.add('hidden');
    const { error } = await sb.auth.signInWithPassword({ email: els.email.value.trim(), password: els.password.value });
    if (error) showLoginError(error.message);
  }
  async function logout(){ await sb.auth.signOut(); }
  function showLoginError(msg){ els.loginError.textContent=msg; els.loginError.classList.remove('hidden'); }

  async function loadAdmin(){
    const { data:e, error:eErr } = await sb.from('elections').select('*').eq('slug', cfg.defaultElectionSlug).single();
    if (eErr) return showStatus(eErr.message, true);
    election = e; candidates = normalizeCandidates(e.candidates);
    const { data:r, error:rErr } = await sb.from('state_results').select('*').eq('election_id', e.id).order('state_name');
    if (rErr) return showStatus(rErr.message, true);
    stateRows = r || [];
    renderElection(); renderRows();
  }
  function normalizeCandidates(raw){
    const arr = Array.isArray(raw) ? raw : JSON.parse(raw || '[]');
    const ids = ['gop','dem','ind'];
    return ids.map((id,i)=> arr.find(c=>c.id===id) || {id,party:id.toUpperCase(),name:id.toUpperCase(),shortName:id.toUpperCase(),color:['#e74c3c','#3498db','#9b59b6'][i],image:''});
  }
  function renderElection(){
    els.title.value = election.title || ''; els.subtitle.value = election.subtitle || ''; els.year.value = election.year || '';
    els.win.value = election.win_threshold || 270; els.totalEv.value = election.total_electoral_votes || 538;
    els.candidates.innerHTML = candidates.map(c => `<div class="candidate-box" data-candidate="${c.id}"><h4>${c.id.toUpperCase()} Candidate</h4><label>Party<input data-field="party" value="${esc(c.party)}"></label><label>Name<input data-field="name" value="${esc(c.name)}"></label><label>Short name<input data-field="shortName" value="${esc(c.shortName||c.party)}"></label><label>Color<input data-field="color" value="${esc(c.color)}"></label><label>Image URL<input data-field="image" value="${esc(c.image||'')}"></label></div>`).join('');
  }
  async function saveElection(){
    const newCandidates = [...els.candidates.querySelectorAll('.candidate-box')].map(box=>{
      const obj = { id: box.dataset.candidate };
      box.querySelectorAll('[data-field]').forEach(inp => obj[inp.dataset.field] = inp.value.trim());
      return obj;
    });
    const payload = { title:els.title.value.trim(), subtitle:els.subtitle.value.trim(), year:els.year.value.trim(), win_threshold:num(els.win.value), total_electoral_votes:num(els.totalEv.value), candidates:newCandidates };
    const { error } = await sb.from('elections').update(payload).eq('id', election.id);
    if (error) showStatus(error.message, true); else { showStatus('Election setup saved.'); await loadAdmin(); }
  }
  async function seedStates(){
    if (!election) return;
    const existing = new Set(stateRows.map(r=>r.abbr));
    const missing = stateBase.filter(s=>!existing.has(s.abbr)).map(s=>({...s,election_id:election.id,total_turnout:0,turnout_pct:0,gop_pct:0,dem_pct:0,ind_pct:0,called_party:''}));
    if (!missing.length) return showStatus('No missing states.');
    const { error } = await sb.from('state_results').insert(missing);
    if (error) showStatus(error.message, true); else { showStatus(`Created ${missing.length} missing state rows.`); await loadAdmin(); }
  }
  function renderRows(){
    const q=(els.search.value||'').toLowerCase();
    els.rows.innerHTML = stateRows.filter(r=>!q||r.state_name.toLowerCase().includes(q)||r.abbr.toLowerCase().includes(q)).map(rowHtml).join('');
    els.rows.querySelectorAll('input,select').forEach(inp=>{ inp.addEventListener('input',()=>{ inp.closest('tr').classList.add('dirty'); updatePreview(inp.closest('tr')); }); });
  }
  function rowHtml(r){
    const preview = calcPreview(r);
    return `<tr data-id="${r.id}" data-abbr="${r.abbr}"><td><span class="state-name">${esc(r.state_name)}</span><br><span class="preview">${r.abbr}</span></td><td><input data-field="electoral_votes" type="number" min="0" value="${r.electoral_votes||0}"></td><td><input data-field="total_turnout" type="number" min="0" value="${r.total_turnout||0}"></td><td><input data-field="turnout_pct" type="number" min="0" max="100" step="0.1" value="${r.turnout_pct||0}"></td><td><input data-field="gop_pct" type="number" min="0" max="100" step="0.1" value="${r.gop_pct||0}"></td><td><input data-field="dem_pct" type="number" min="0" max="100" step="0.1" value="${r.dem_pct||0}"></td><td><input data-field="ind_pct" type="number" min="0" max="100" step="0.1" value="${r.ind_pct||0}"></td><td><select data-field="called_party"><option value="" ${!r.called_party?'selected':''}>Auto / none</option><option value="gop" ${r.called_party==='gop'?'selected':''}>GOP</option><option value="dem" ${r.called_party==='dem'?'selected':''}>DNC</option><option value="ind" ${r.called_party==='ind'?'selected':''}>IND</option></select></td><td class="preview-counted">${preview.counted.toLocaleString()}</td><td class="preview-leader">${preview.leader}</td></tr>`;
  }
  function updatePreview(tr){
    const r = readRow(tr); const p = calcPreview(r);
    tr.querySelector('.preview-counted').textContent = p.counted.toLocaleString();
    tr.querySelector('.preview-leader').textContent = p.leader;
  }
  function readRow(tr){
    const old = stateRows.find(r=>r.id===tr.dataset.id) || {};
    const out = {...old};
    tr.querySelectorAll('[data-field]').forEach(inp=>{ out[inp.dataset.field] = inp.tagName==='SELECT' ? inp.value : num(inp.value); });
    return out;
  }
  function calcPreview(r){
    const counted = Math.round(num(r.total_turnout) * num(r.turnout_pct) / 100);
    const votes = { GOP:Math.round(counted*num(r.gop_pct)/100), DNC:Math.round(counted*num(r.dem_pct)/100), IND:Math.round(counted*num(r.ind_pct)/100) };
    const leader = Object.entries(votes).sort((a,b)=>b[1]-a[1])[0];
    return {counted, leader: `${leader[0]} (${leader[1].toLocaleString()})`};
  }
  async function saveAllRows(){
    const updates = [...els.rows.querySelectorAll('tr')].map(readRow).map(r=>({ id:r.id, election_id:election.id, abbr:r.abbr, state_name:r.state_name, electoral_votes:num(r.electoral_votes), total_turnout:num(r.total_turnout), turnout_pct:clamp(num(r.turnout_pct)), gop_pct:clamp(num(r.gop_pct)), dem_pct:clamp(num(r.dem_pct)), ind_pct:clamp(num(r.ind_pct)), called_party:r.called_party || '' }));
    if (!updates.length) return showStatus('No visible rows to save.', true);
    const { error } = await sb.from('state_results').upsert(updates, { onConflict:'id' });
    if (error) showStatus(error.message, true); else { showStatus(`Saved ${updates.length} visible rows.`); await loadAdmin(); }
  }
  function normalizeVisible(){
    els.rows.querySelectorAll('tr').forEach(tr=>{
      const g=tr.querySelector('[data-field="gop_pct"]'), d=tr.querySelector('[data-field="dem_pct"]'), i=tr.querySelector('[data-field="ind_pct"]');
      const sum = num(g.value)+num(d.value)+num(i.value); if (!sum) return;
      g.value=(num(g.value)/sum*100).toFixed(2); d.value=(num(d.value)/sum*100).toFixed(2); i.value=(num(i.value)/sum*100).toFixed(2);
      tr.classList.add('dirty'); updatePreview(tr);
    });
  }
  function showStatus(msg,bad=false){ els.status.textContent=msg; els.status.classList.toggle('bad',bad); els.status.classList.remove('hidden'); }
  function num(v){ return Number(v || 0); } function clamp(v){ return Math.max(0, Math.min(100, Number(v||0))); }
  function esc(s){ return String(s ?? '').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m])); }
})();
