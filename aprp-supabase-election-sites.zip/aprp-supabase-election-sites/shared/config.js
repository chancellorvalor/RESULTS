/* APRP Election shared config
   Put your Supabase project URL and anon public key here after creating the project.
   The anon key is safe to publish when Row Level Security policies are enabled from sql/schema.sql.
*/
window.APRP_CONFIG = {
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR-SUPABASE-ANON-PUBLIC-KEY',
  refreshSeconds: 15,
  defaultElectionSlug: 'current'
};
